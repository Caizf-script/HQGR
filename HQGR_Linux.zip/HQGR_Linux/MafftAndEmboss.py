import os
import argparse
import time
#cmd command
def popen(cmd, mode="r", buffering=-1):
    if not isinstance(cmd, str):
        raise TypeError("invalid cmd type (%s, expected string)" % type(cmd))
    if mode not in ("r", "w"):
        raise ValueError("invalid mode %r" % mode)
    if buffering == 0 or buffering is None:
        raise ValueError("popen() does not support unbuffered streams")
    import subprocess, io
    if mode == "r":
        proc = subprocess.Popen(cmd,
                                shell=True,
                                stdout=subprocess.PIPE,
                                bufsize=buffering)
        return _wrap_close(io.TextIOWrapper(proc.stdout), proc)
    else:
        proc = subprocess.Popen(cmd,
                                shell=True,
                                stdin=subprocess.PIPE,
                                bufsize=buffering)
        return _wrap_close(io.TextIOWrapper(proc.stdin), proc)

#Calling MAFFT
def getMafftFile(path,MafftOutput,MafftAddress):
    ## dict: filename(cons) ==> filename(no cons)
    f_list = os.listdir(path)
    for i in f_list:
        print(f"file name: {i} to be processed")
        if '5p--3p' in os.path.splitext(i)[0] and 'aligned' not in os.path.splitext(i)[0] and 'cons' not in os.path.splitext(i)[0] and os.path.splitext(i)[1] == '.fasta':
            MafftName = os.path.splitext(i)[0]+'_aligned'
            cmdMafft = MafftAddress + r' --reorder --retree 1 --maxiterate 0 --out '+ path +'/'+ MafftName + MafftOutput +' '+ path +'/'+i
            print(f"commands will be run: {cmdMafft}")
            d = os.system(cmdMafft) ##d = os.popen(cmdMafft)
            print("commands successed!")
    origin_file_dict = dict()
    for file in os.listdir(path):
        if '5p--3p' in file and "_aligned" not in file and "_cons" not in file and file.endswith(".fasta"):
            origin_file = file
            cons_file = "{}_aligned_cons.fasta".format(origin_file[:-6])
            origin_file_dict[cons_file] = origin_file
    return origin_file_dict
     
#Calling EMBOSS
def getEmbossFile(path,emBossOutput,ConsAddress):
    origin_name_dict ={}
    f_list = os.listdir(path)
    for i in f_list:
        if 'aligned' in os.path.splitext(i)[0]:
            with open(os.path.join(path, i)) as f :
                l = f.readline()
                if l[0]=='>':
                    origin_name = l
                    for line in f:
                        if line[0] == '>':
                            origin_name = origin_name+';'+ line
                        else: continue
                    origin_name_dict[i+'_cons']= origin_name
            embossName = os.path.splitext(i)[0]+'_cons'
            cmdEmboss = ConsAddress + ' -sequence '+ path +'/'+ i +' -outseq '+ path +'/'+ embossName + emBossOutput
            d = os.system(cmdEmboss) ## d = os.popen(cmdEmboss)
    return origin_name_dict
    
def countFileNumber(path,fname,fname1='',fname2=''):
    f_list = os.listdir(path)
    fileNumber = 0
    for i in f_list:
        if fname in os.path.splitext(i)[0] and fname1 not in os.path.splitext(i)[0] and fname2 not in os.path.splitext(i)[0]:
            fileNumber=fileNumber+1
    return fileNumber

def MafftAndEmbosses(path,MafftAddress,ConsAddress):
    path = path
    MafftOutput='.afa'
    emBossOutput='.fasta'
    start = time.perf_counter()

    MafftFlieNumber = countFileNumber(path,'5p--3p','aligned','cons') 

    origin_name_dict = getMafftFile(path,MafftOutput,MafftAddress) ## _aligned

    embossFileNumber = countFileNumber(path,'aligned', "cons", "cons") 

    while(MafftFlieNumber != embossFileNumber):
        embossFileNumber = countFileNumber(path,'aligned', "cons", "cons") 
        # print(f"please be patient, need more aligned files to be generated")

    tmp_dict = getEmbossFile(path,emBossOutput,ConsAddress)
    ## after a while
    # print(f"generated cons and wait until all cons files are generated")
    consFileNum = countFileNumber(path,'aligned_cons', "conscons", "conscons") 
    while(MafftFlieNumber != consFileNum):
       consFileNum = countFileNumber(path,'aligned_cons', "conscons", "conscons") 
       ## wait
    cons_size = [os.path.getsize(f"{path}/{file}") for file in os.listdir(path) if "_aligned_cons" in file ]
    cons_size.sort()
    while cons_size[0] <= 0:
        cons_size = [os.path.getsize(f"{path}/{file}") for file in os.listdir(path) if "_aligned_cons" in file ]
        cons_size.sort()
    #print("finally we get all cons files ready")
    
    f_list = os.listdir(path)
    sequence = ''
    length_dict={}
    p0 = os.getcwd()
    for i in f_list:
        if 'cons' in os.path.splitext(i)[0]:
            if os.path.exists(f"{p0}/{path}/{i}"):
                    f = open(f"{p0}/{path}/{i}", encoding = "utf-8")
                    k = f.readline()
                    while len(k):
                        if len(k.strip()) & k.startswith(">"):
                            origin_name = k
                        elif len(k.strip()):
                            sequence += k
                        k = f.readline()
                    length_dict[i] = len(sequence)
                    f.close()
    end = time.perf_counter()
    print('\n'+'Consensus sequence generation finished，Time:%.2f'%(end-start))
    return origin_name_dict,length_dict
if __name__=='__main__':
    MafftAndEmbosses(Outputpath, MafftAddress, ConsAddress)


