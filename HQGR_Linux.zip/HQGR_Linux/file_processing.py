import os
from openpyxl import Workbook

def file_processing(sequencepath,min,max,Outputpath):
    sequencedict={}
    fw = open(os.path.split(sequencepath)[0] +'/remained.fasta','w')
    sequence = ''
    below_length = 0
    above_length = 0
    total = 0
    with open(sequencepath,'r') as f_p:
        l = f_p.readline().strip('\n')
        if l[0] == '>':
            name = l
            for line in f_p:
                if line[0]=='>' or line=='':
                    total +=1
                    name=l
                    # print(line)
                    # print(name)
                    newname = line
                    l=line.strip('\n')

                    if name[0]=='>'and line!='\n':
                        if len(sequence)> min and len(sequence)< max:
                            sequencedict[name] = sequence
                            fw.write(name+'\n'+sequence+'\n')

                        elif len(sequence)< min:
                            below_length += 1

                        elif len(sequence)> max:
                            above_length += 1
                            
                    sequence=''

                else:
                    sequence += line.strip('\n')

            total += 1
            fw.write(newname + sequence)

            file_count ='./Filter_report.xlsx'

            wb = Workbook()
            ws1 = wb.create_sheet(u'Filter')
            ws1['A1'] = u'Filter'
            ws1['A2'] = u'Reads for'
            ws1['A3'] = u'Above length'
            ws1['B3'] = above_length
            ws1['C3'] = format(above_length/total,'.2%')
            ws1['A4'] = u'Below length'
            ws1['B4'] = below_length
            ws1['C4'] = format(below_length / total, '.2%')
            ws1['A5'] = u'Total'
            ws1['B5'] = total
            ws0 = wb["Sheet"]
            wb.remove(ws0)
            wb.save(file_count)

if __name__ == "__main__":
    file_processing(sequencepath,min,max,'./')