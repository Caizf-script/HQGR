#!/usr/bin/python
import os
import time
import shutil
from openpyxl import Workbook
from Bio.Seq import Seq
import MafftAndEmboss
import argparse
import file_processing
##
if __name__ == '__main__':
    starttime = time.perf_counter()
    parser = argparse.ArgumentParser(
        description='HQGR was designed to implement second round of CCS for long amplicon HiFi sequencing.')
    parser.add_argument('-min', '--min', type=int,default=8000)
    parser.add_argument('-max', '--max', type=int,default=100000)
    parser.add_argument('-i', '--sequencepath', type=str, default=r'./example/N1000_8to10.fa')
    parser.add_argument('-d', '--primerpath', type=str, default=r'./example/barcode.fasta')
    parser.add_argument('-o', '--Outputpath', type=str, default=r'./subread')
    parser.add_argument('-fl', '--frblen', type=int, default=36)
    parser.add_argument('-bl', '--beblen', type=int, default=23)
    parser.add_argument('-MAd', '--MafftAddress', type=str, default=r'./mafft-win/mafft.bat')
    parser.add_argument('-CoAd', '--ConsAddress', type=str, default=r'/GS01/software/biosoft/EMBOSS-6.6.0/tools/bin/cons')

    args = parser.parse_args()
    primerpath = args.primerpath
    sequencepath = args.sequencepath
    Outputpath = args.Outputpath
    min = args.min
    max = args.max
    frblen = args.frblen
    beblen = args.beblen
    MafftAddress = args.MafftAddress
    ConsAddress = args.ConsAddress
    file_processing.file_processing(sequencepath,min,max,Outputpath)
    f1rr1={}
    r1rf1={}
    f3rr3={}
    r3rf3={}
    
#### Clearing output directory.
    if os.path.exists(Outputpath):
        shutil.rmtree(Outputpath)
#### Refined barcode and primer sequences.
    with open(primerpath,'r') as bf1:
        for line in bf1:
            if line[0]=='>':
                name=line.strip('>\n\r')
            elif line!='\n':
                sequence = line.strip('\n')
                if name[-3:] == '_5p':
                    f1rr1.setdefault(sequence, name)
                    name2='R-'+name
                    rev = list(sequence)

                    r_rev = []
                    j = -1
                    for i in range(len(rev)):
                        r_rev.append(rev[j])
                        j -=1
                    R = r_rev
                    rr_se=''
                    for i in range(len(r_rev)):
                        if r_rev[i] == 'A':
                            R[i] = 'T'
                        elif r_rev[i] == 'T':
                            R[i] = 'A'
                        elif r_rev[i] == 'C':
                            R[i] = 'G'
                        elif r_rev[i] == 'G':
                            R[i] = 'C'
                        rr_se+=R[i]

                    r1rf1.setdefault(rr_se, name2)
                elif name[-3:] == '_3p':
                    print(1)
                    r1rf1.setdefault(sequence, name)
                    name = 'R-' + name
                    rev = list(sequence)

                    r_rev = []
                    j = -1
                    for i in range(len(rev)):
                        r_rev.append(rev[j])
                        j -= 1
                    R = r_rev
                    rr_se=''
                    for i in range(len(r_rev)):
                        if r_rev[i] == 'A':
                            R[i] = 'T'
                        elif r_rev[i] == 'T':
                            R[i] = 'A'
                        elif r_rev[i] == 'C':
                            R[i] = 'G'
                        elif r_rev[i] == 'G':
                            R[i] = 'C'
                        rr_se+=R[i]
                    f1rr1.setdefault(rr_se, name)

    File_Path = Outputpath
    print("File_path: " + File_Path)
    total={}
    if not os.path.exists(File_Path):
        os.makedirs(File_Path)
    hu=1
#### Barcode and primer matched
    with open(sequencepath,'r') as Reads:
        for line in Reads:
            if line[0]=='>' or line=='':
                name=line.strip('\n')
                sequence = Reads.readline().strip(' \r\n')
                if name[0]=='>'and line!='\n':
                    #Match 5p-3p
                    print(sequence[0:frblen])
                    print(sequence[beblen:])
                    if sequence[0:frblen].strip('\r\n ') in f1rr1.keys() and sequence[-beblen:].strip('\r\n ') in f1rr1.keys():
                        name1=f1rr1[sequence[0:frblen].strip('\r\n ')]
                        name2=f1rr1[sequence[-beblen:].strip('\r\n ')]

                        full_name = Outputpath+'/'+ name1[:-2] + name2[2:-2] + name1[-2:] + '--'+ name2[-2:]+'.fasta'
                        print("full_name" + full_name)

                        if full_name.lstrip(Outputpath) in total.keys():
                            total[full_name.lstrip(Outputpath+'/ ')]+=1
                        else:
                            total[full_name.lstrip(Outputpath+'/ ')]=1
                        with open(full_name.strip(' '),'a') as file1:
                            file1.write(name+'\n'+sequence[frblen:-beblen] + '\n')
                    #Match 3p-5p
                    if sequence[0:beblen].strip('\r\n ') in r1rf1.keys() and sequence[-frblen:].strip('\r\n ') in r1rf1.keys():
                        name1=r1rf1[sequence[0:beblen]]
                        name2=r1rf1[sequence[-frblen:].strip('\r')]
                        full_name = Outputpath+'/'+ name1[0:-2] + name2[2:-2] + name1[-2:] + '--'+ name2[-2:]+'.fasta'
                        print(full_name)

                        with open(full_name.strip(' '), 'a') as file1:
                            file1.write(name+'\n'+sequence[beblen:-frblen]+ '\n')
                        my_seq = Seq(sequence[beblen:-frblen])
                        my_seq = my_seq.reverse_complement()
                        reverse_se = str(my_seq)
                        full_name = Outputpath+'/'+ name1[0:-2] + name2[2:-2] + name2[-2:] + '--'+ name1[-2:]+'.fasta'
                        if full_name.lstrip(Outputpath+'/') in total.keys():
                            total[full_name.lstrip(Outputpath+'/ ')]+=1
                        else:
                            total[full_name.lstrip(Outputpath+'/ ')]=1
                        with open(full_name.strip(' '), 'a') as file1:
                            file1.write(name+'\n'+reverse_se + '\n')
    endtime = time.perf_counter()
    print('Runtime161:',endtime-starttime)
    file_count = Outputpath +'/count.xlsx'
    wb = Workbook()
    ws1 = wb.create_sheet(u'Demultiplex')
    ws1['A1']=u'name'
    ws1['B1']=u'Counts'
    row_range = ws1['A':'B']
    so = sorted(total.keys())
    for i in range(len(so)):
        i+=1
        ws1['A'+str(i+1)] = so[i-1]
        ws1['B'+str(i+1)] = str(total[so[i-1]])
    path = Outputpath
    eo = r'.fasta'
    origin_name_dict,total_length_dict = MafftAndEmboss.MafftAndEmbosses(Outputpath,MafftAddress,ConsAddress)

    ws2 = wb.create_sheet(u'report')
    ws2['A1'] = u'cons name'
    ws2['B1'] = u'length'
    ws2['C1'] = u'origin ccs name'

    row_range = ws2['A':'B']
    so = sorted(origin_name_dict.keys())
    for i in range(len(so)):
        i += 1
        ws2['A' + str(i + 1)] = so[i - 1] ## cons filename
        ws2['B' + str(i + 1)] = str(total_length_dict[so[i - 1]])  ## length for cons fasta file
        ws2['C' + str(i + 1)] = origin_name_dict[so[i - 1]]  ## file name before cons
    ws0 = wb["Sheet"]
    wb.remove(ws0)
    wb.save(file_count)